#!/bin/bash
# Author
#    2018/11/25  Qipeng Bai

dir="./cmds";
crust1="${dir}/crust1"
crust2="${dir}/crust2"
snr="${dir}/select"

cd $dir;
chmod +x *.pl *.sh *.cmd *.awk 
cd -

cd $crust1
chmod +x getCN1point getCN1maps
cd -

cd $crust2
chmod +x getCN2point map2gmt
cd -

cd $snr
chmod +x snr select.pl selectSNR_*.pl
cd -

#cp $dir/LeadDataTel_v0.1.sh ./
#cp $dir/LeadDataLoc_v0.3.sh ./

rm -rf RESP Vel data
