#! /bin/bash

basepath=$(pwd)

# --> Set basic default factors
cd datatel/

preliminary_depth=`saclst evdp f *.z | head -1 | gawk '{printf("%d",$2);}'`
bg_preliminary_depth=$[$preliminary_depth-10]
if [ "$bg_preliminary_depth" -lt 1 ]
then
bg_preliminary_depth=1
fi
nd_preliminary_depth=$[$preliminary_depth+10]
prel_dep_interval=1
default_frequency_range="0.02/0.1/0.02/0.05";
default_lower_mangnitude_frequency_range="0.01/0.07/0.01/0.05";
mag=`saclst mag f *.z | head -1 | gawk '{print $2;}'`
dur=$(echo ${mag} | gawk '{printf ("%.1f",0.7*3.5^($1-4.8));}')
model_name="vmodel"
cd ..

# --> gen. cap_3.sh depsol_3.sh
echo -e "#!/bin/bash\n\nC=0.02/0.1/0.02/0.05\nJ=0/0/-0.5/0.1\nI=5/0.1\nL="$dur"\nP=-P0.3/200/k\nS=5/10/0\nT=150/200\nw_TEL_LOC=200\nw_P_SH=1\ns_P_SH=0\n\nperl cmds/gcap.pl -A\$w_TEL_LOC/\$w_P_SH/\$s_P_SH -C\$C -D1/0/0 -GgreenFuncDir -H0.2 -I\$I -J\$J -L\$L -M"$model_name"_\$1/"$mag" \$P -W1 -R0/360/0/90/-180/180 -S\$S -T\$T data -Zweight.dat\nrm ./data/"$model_name"_*.[0-9]" > $basepath/gcap.sh
echo -e "#!/bin/bash\n\nfor((j="$bg_preliminary_depth";j<="$nd_preliminary_depth";j=j+1));\ndo\n\tsh gcap.sh \$j;\ndone\n# Output the results to the main directory\ncp cmds/mecherr.sh data\ncd data\nsh mecherr.sh\ncd ../\ncp data/*.ps output/\n" > $basepath/depth.sh
#echo -e "$bg_preliminary_depth\t$nd_preliminary_depth" > $basepath/search_range.lst
chmod +x $basepath/gcap.sh $basepath/depth.sh
echo -e "\033[35m Generate gcap.sh depth.sh \033[0m"

cd $basepath
cp cmds/weight.sh .
sh weight.sh
mkdir data output
cp datatel/*.[rtz] data/
cp dataloc/*.[rtz] data/
mv weight.dat.JOINT data/weight.dat
rm -rf weight.sh
