#!/bin/sh

SAC_DISPLAY_COPYRIGHT=0

# --> set directories
if [ -d SEED ]; then
echo "found SEED/";
else
mkdir SEED;
fi
if [ -d RESP ]; then
echo "found RESP/"
else
mkdir RESP
fi
if [ -d data ]; then
echo "found data/";
else
mkdir data;
fi
if [ -d Vel ]; then
echo "found Vel/";
else
mkdir Vel;
fi
echo -e "\033[35m Generate directories \033[0m"

# --> rdseed the seed file, modify the sac header
cp tel.seed SEED/ # --> save tel.seed
seedname=$(ls -1 tel.seed | gawk '{print $1}')
rdseed -f $seedname -c |grep -i Event > event.location.info
cat event.location.info | gawk '
 /origin/ {x=$5;
 split(x,aa,",");
 split(aa[3],bb,":");
 print "r $1";
 print "chnhdr o gmt ",aa[1],aa[2],bb[1],bb[2],bb[3];
 print "evaluate to tt1 &1,o * -1";
 print "chnhdr allt %tt1";
}
/latitude/ {print "ch evla",$4}
/longitude/ {print "ch evlo",$4}
/depth/ {print "ch evdp",$5}
END{
 print "w over";
}' > cho.sm
rdseed -pdf $seedname;
find . -name "*.SAC" > 1SAC1
cat 1SAC1 | awk 'BEGIN {FS="/";} {if (!$3) print $2;}' >1SAC2
cat 1SAC2 | gawk '{split($1,m,".");print "mv "$1, m[7]"."m[8]"."m[9]"."m[10]}' | sh
find . -name "*.BH?" > 1BH
cat 1BH | awk 'BEGIN {FS="/";} {if (!$3) print $2;}' > 2BH
cat 2BH | gawk '{print "r ",$1;print "m cho.sm ",$1;} END {print "quit"}' | sac
rm cho.sm rdseed.err_log
mv event.location.info Vel/ 
rm -rf *.[1-9]0.BH? 
echo -e "\033[35m Modify the original time \033[0m"

# --> remove the instrumental response
find . -name "SAC_PZs*" > 1PZs
cat 1PZs | awk '
BEGIN {FS="/";} 
{	if (!$3) print $2;
}' > 2PZs
cat 2PZs | gawk '
{	split($1,mm,"_");
	print "mv",$1,"RESP/"mm[3]"."mm[4]"."mm[6]"."mm[5]
}' | sh
find . -name "*.BH?" > BH1
cat BH1 | awk 'BEGIN {FS="/";} {if (!$3) print $2;}' > BH2
cat BH2 |gawk '{
	print "r",$1;
	print "rmean";
	print "rtr";
	print "transfer from polezero subtype RESP/"$1,"to vel freq 0.001 0.005 10 20";print "w Vel/"$1
}
END{print "q"}' | sac
rm [12]PZs BH[12] 1SAC[12] [12]BH *.BH[12ENZ]
cd Vel/
echo -e "\033[35m Remove the instrumental response \033[0m"

# --> interpolate or decimate/stretch --> delta--0.2
saclst delta f *.*.*.* | gawk '{
	if($2==0.1){
		print "r",$1;
		print "decimate 2";
		print "w over";
	}
	if($2==0.025){
		print "r",$1;
		print "decimate 2";
		print "decimate 2";
		print "decimate 2";
		print "w over"
	}
	if($2==0.01){
		print "r",$1;
		print "decimate 5";
		print "decimate 2";
		print "decimate 2";
		print "w over";
	}
	if($2==0.005){ 
		print "r",$1;
		print"decimate 2";
		print "decimate 5";
		print"decimate 2";
		print"decimate 2";
		print "w over";
	}
        if($2==0.05){
                print "r",$1;
		print"decimate 2";
		print"decimate 2";
                print "w over";
        }
	if($2==0.02){
		print "r",$1;
		print"decimate 2";
		print "decimate 5";
		print "w over";
	}
} END{print "quit"}' | sac
echo -e "\033[35m Modify the sampling frequency to 0.2 \033[0m"

# --> Remove stations that do not have 3 components
ls -1 *.BH* | gawk '
BEGIN{
        FS=".";
        num=0;
        a="AA";b="AAA";c="AA";
        }
{
        if ($1==a&&$2==b&&$3==c)
                {num+=1;}
        else if(num<=2&&(a!="AA"||b!="AAA"))
                {       print "rm "a"."b"."c".*";
                        num=1;a=$1;b=$2;c=$3}
                else {  num=1;a=$1;b=$2;c=$3}
}
END{
        if (num<=2) print "rm "a"."b"."c".*";
}' | sh

# --> Remove "IM" stations and add P or S arrival times
rm ./IM.*.?H?
sh ../cmds/addp.cmd *.BHZ
sh ../cmds/adds.cmd *.BH[EN12]
echo -e "\033[35m Add P or S arrival times \033[0m"

# --> change those stations which CMPAZs have minor error
ls -1 *.BHZ | gawk '{
        print "saclst cmpaz f *.BH1 > 1az.dat";
        print "saclst cmpaz f *.BH2 > 2az.dat";
        print "saclst cmpaz f *.BHE > eaz.dat";
        print "saclst cmpaz f *.BHN > naz.dat";
}' | sh
paste 1az.dat 2az.dat > 12az.dat
paste eaz.dat naz.dat > enaz.dat
cat 12az.dat | gawk '{
        diff1=($2+360-$4)%360;
        pota4=($2+270)%360;
        diff2=($4+360-$2)%360;
        potb4=($2+90)%360;
        if (diff1<diff2) {
                if (diff1!=90) print $3,pota4;
        }
        else {
                if (diff2!=90) print $3,potb4;
        }
}' | awk '{
        print "r "$1;
        print "ch cmpaz "$2;
        print "wh";
}
END{ print "q";}' | sac
cat enaz.dat | gawk '{
        diff1=($2+360-$4)%360;
        pota4=($2+270)%360;
        diff2=($4+360-$2)%360;
        potb4=($2+90)%360;
        if (diff1<diff2) {
                if (diff1!=90) print $3,pota4;
        }
        else {
                if (diff2!=90) print $3,potb4;
        }
}' | awk '{
        print "r "$1;
        print "ch cmpaz "$2;
        print "wh";
}
END{ print "q";}' | sac
rm *az.dat

# --> Rot to gcp
mkdir rtr_mul_100/
ls *BHE | gawk '{split($1,aa,"BH");print"mv",$1,aa[1]"BH1";}' | sh
ls *BHN | gawk '{split($1,aa,"BH");print"mv",$1,aa[1]"BH2";}' | sh
saclst t1 b e f *.BHZ | gawk 'BEGIN{time_begin=t2-50;time_end=$2+300;} {if($3<time_begin&&$4>time_end) print "cut "$2-50,$2+300; a=$1;print "r "$1 ;print "rtr" ;print "mul 100"; gsub("BHZ","z",a);print "ch b 0 a -12345 t1 50 t2 250 t3 50 t4 250";print "w rtr_mul_100/"a ;print "cut t1 -50 t1 300"; a=$1; b=$1; gsub("BHZ", "BH1",a); gsub("BHZ","BH2", b);print "r",a,b; print "rtr" ; print "mul 100"; print "rot to gcp"; gsub("BH1","r",a); gsub("BH2","t",b); print "ch b 0 a -12345 t1 50 t2 250 t3 50 t4 250"; print "w rtr_mul_100/"a, "rtr_mul_100/"b;} END {print "quit";}' | tee | sac
echo -e "\033[35m Rotate to GCP && CUT \033[0m"

# --> Move repeating data away and start doing gCAP
cd rtr_mul_100
read -p " SNR? yes|no: " choose
case $choose in
	yes) echo 'You select yes'
# --> SNR: select data
perl ../../cmds/snr/SNR.pl
rm *.[rtz]
mv ./good_data/*.[rtz] ../../data/
rm -rf good_data
cd ../../
cd data/
mkdir others
mv *.[1-9]0.* others > /dev/null
cd ../
	;;

	no) echo 'You select no'
mv *.[rtz] ../../data/
cd ../../
rm -rf RESP
cd data/
mkdir others
mv *.[1-9]0.* others > /dev/null
cd ../
	;;
esac

# --> reserve the specified number of teleseismic stations 
cp cmds/snr/select.pl ./
perl select.pl data/

cd data/
mkdir all_stations/
cp *.[rtz] all_stations/
rm -rf select_stations/ excluding_stations/

mkdir select_stations 
saclst user0 f *.z | sort -r -nk2 | head -100 | gawk '{split($1,aa,".");
                                                                print "mv "aa[1]"."aa[2]"."aa[3]".r" ,"select_stations/";
                                                                print "mv "aa[1]"."aa[2]"."aa[3]".t" ,"select_stations/";
                                                                print "mv "aa[1]"."aa[2]"."aa[3]".z" ,"select_stations/"}' | sh
mkdir excluding_stations
mv *.[rtz] excluding_stations/
cp select_stations/*.[rtz] .
cd -
mv data datatel

# --> calculate the teleseismic Green's functions by TEL4
cp cmds/tel4.sh ./
sh tel4.sh

mv Vel/ RESP/ datatel/
rm -rf tel4.sh select.pl tel.seed
