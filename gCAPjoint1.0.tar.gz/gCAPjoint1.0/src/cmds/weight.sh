#!/bin/bash

basepath=$(pwd)

# --- loc
cd dataloc/
saclst dist az f *.z | sort -nk3 | gawk '{gsub(".z","",$1); printf "%s %d 1 1 1 1 1 0 0 \n",$1,$2 }' > weight.dat.LOC
cd ../

# --- tel
cd datatel/
saclst dist az f *.z   | sort -nk3 | gawk '{gsub(".z","",$1); printf "%s %d 1 0 0 0 1 0 0 \n",$1,$2 }' > weight.dat.TEL
cd ../

cat dataloc/weight.dat.LOC > ./weight.dat.JOINT
cat datatel/weight.dat.TEL >> ./weight.dat.JOINT
echo -e "\033[35m Generate weight file \033[0m"

