#!/bin/sh
# depthRange/mismatchRange divDepth divMismatch 
if [ $# == 0 ]
then

cat  *_*.out |grep ERR |gawk '{gsub($2,""); print $0 }'|gawk '{gsub("_"," ");print $4,$12}' | sort -n > yyy.dat
perl ../cmds/mindepth.pl > quadratic.dat
echo "# Full moment"
echo "#    usage:"
echo "#          depthRange/mismatchRange divDepth divMismatch"
echo "#"
gawk '{printf "The real depth is %5.2f \n",$2}' quadratic.dat
gawk '{for(i=1;i<50;i=i+0.1) print i,$1*(i-$2)^2+$3}' quadratic.dat > new.dat

cat *_*.out | grep ERR |gawk '{gsub($2,""); print $0 }'|gawk '{gsub("_"," ");print $4,$12,$10;}' > moment_temp1
cat *_*.out | grep MomentTensor | gawk '{gsub($3,""); print $0 }' | gawk '{print $4,$5,$6,$7,$8,$9,25;}' > moment_temp2
paste -d ' ' moment_temp1 moment_temp2 | gawk '{print "#"$1,$2,10,$4,$5,$6,$7,$8,$9,$10,$1,$2,$3}'

cat  *_*.out |grep ERR |gawk '{gsub($2,""); print $0 }'|gawk '{gsub("_"," ");print $4,$12,10,$6,$7,$8,$10,$4,$12,$10}' | gawk 'BEGIN{min1=1e+5;max1=-1e+5;min2=1e+10;max2=-1e+5}  $1 < min1 { min1=$1  } $1 > max1 { max1=$1 }; $2 < min2 { min2=$2 } $2 > max2 { max2=$2 } END { printf "#\tDep_min = %-12d Mismatch_min = %9.4f\n#\tDep_max = %-12d Mismatch_max = %9.4f\n\n",min1,min2,max1,max2 ; print "sh mecherr.sh "min1-(max1-min1)/10  "/" max1+(max1-min1)/10 "/" min2-(max2-min2)/10 "/" max2+(max2-min2)/10 ,(max1-min1)/10  ,(max2-min2)/10 }' | sh

#exit

else

cat *_*.out |grep ERR |gawk '{gsub($2,""); print $0 }'|gawk '{gsub("_"," ");print $4,$12,$10;}' > moment_temp1
cat *_*.out |grep MomentTensor | gawk '{gsub($3,""); print $0 }' | gawk '{print $4,$5,$6,$7,$8,$9,25;}' > moment_temp2
paste -d ' ' moment_temp1 moment_temp2 | gawk '{print $1,$2,10,$9,$4,$7,$6,-$8,-$5,$10,$1,$2,$3}' | psmeca -X2i -Y2i -Sm0.2i -R$1 -JX5i/6.5i -P -K -Ba2f1:"Depth (km)":/a$3:"Mismatch":WSne > mecherr.ps
#dep=$(cat *_*.out|grep ERR | gawk '{ gsub($2,""); print $0 }' |gawk '{gsub("_"," ");print $4,$12;}' | gawk 'BEGIN {num=0;temp=9999999999;} {if ($2<=temp) {temp=$2;num=$1;}} END {print num;}')
#paste -d ' ' moment_temp1 moment_temp2 | gawk '{if($1=='$dep') print $1,$2,10,$9,$4,$7,$6,-$8,-$5,$10,$1,$2,$3}' | psmeca -Sm0.2i -R$1 -JX5i/6.5i -G255/0/0 -O -K -Ba2f1:"Depth (km)":/a$3:"Mismatch":WSne >> mecherr.ps

#psxy new.dat -R -JX -W2p/0/0/0 -O -K >> mecherr.ps

themid=`gawk '{print $2}' quadratic.dat`

echo "$themid" 0 > dash.dat
echo "$themid" 1e9 >> dash.dat
psxy dash.dat -R -JX -G0 -W1t5_5:2p/0/0/0 -O >> mecherr.ps

rm moment_temp1 moment_temp2
fi
