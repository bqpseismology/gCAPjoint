#! /bin/bash
SAC_DISPLAY_COPYRIGHT=0;

# --> Set basic default factors
cd datatel/
t_star_p=1
t_star_s=4
model_name="vmodel"
preliminary_depth=$(ls -1 *.z | gawk ' BEGIN{j=1;} {if(j<=1) print $1;j++;}' | gawk '{print "saclst evdp f "$1;}' | sh | gawk '{printf("%d",$2);}')
bg_preliminary_depth=$[$preliminary_depth-10]
if [ "$bg_preliminary_depth" -lt 1 ]
then
bg_preliminary_depth=1
fi
nd_preliminary_depth=$[$preliminary_depth+10]
prel_dep_interval=1

# --> Generate CRUST2 Velocity Model--tel
ls -1 *.z | gawk ' BEGIN{j=1;} {if(j<=1) print $1;j++;}' | gawk '{print "saclst evla evlo f "$1;}' | sh | gawk '{print $2,$3;}' > lalo.dat
cp -r ../cmds/crust2/ .
cp lalo.dat ./crust2/
cd ./crust2/
cat lalo.dat | gawk '{print $0;} END{print "*";}' | ./getCN2point 
cp outcr ../
rm lalo.dat
cd ../
cat outcr | gawk 'NR>=6&&$1!=0{if($3!=0) {print $2,$3,$4,$1;} else {print $2,$3+0.01,$4,$1;}}' > model.tmp
if [ $preliminary_depth -le 70 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+1;}')
echo -e "#"$model_name" model" > $model_name
echo -n $t_star_p" "$t_star_s" "$num_layer" " >> $model_name
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_35 >>$model_name
fi
if [ $preliminary_depth -gt 70 ] && [ $preliminary_depth -le 300 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+3;}')
echo -e "#"$model_name" model" > $model_name
echo -n $t_star_p" "$t_star_s" "$num_layer" " >> $model_name
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_310 >>$model_name
fi
if [ $preliminary_depth -gt 300 ] && [ $preliminary_depth -le 400 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+3;}')
echo -e "#"$model_name" model" > $model_name
echo -n $t_star_p" "$t_star_s" "$num_layer" " >> $model_name
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_410 >>$model_name
fi
if [ $preliminary_depth -gt 400 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+4;}')
echo -e "#"$model_name" model" > $model_name
echo -n $t_star_p" "$t_star_s" "$num_layer" " >> $model_name
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_660 >>$model_name
fi
rm -rf ./crust2 lalo.dat model.tmp outcr  
echo -e "\033[35m Generate Crust2 velocity model \033[0m"

# --> detect greenFuncDir
if [ -d greenFuncDir ]; then
	echo "found greenFuncDir"
else
	mkdir ../greenFuncDir
fi

# --> Calculate Green's Functions using tel4
distlst=`saclst dist gcarc f *.z | gawk '{if($3>=30&&$3<=90) printf "%d ",$2} END {printf "\n"}'`
#saclst dist az f *.z | sort -nk3  | gawk '{gsub(".z","",$1); printf "%s %d %s\n", $1,$2,"1 0 0 0 1 0 0 0"}' > weight.dat
gawk -v mdn="$model_name" -v dist="$distlst" -v bpd="$bg_preliminary_depth" -v npd="$nd_preliminary_depth" -v pdi="$prel_dep_interval" 'BEGIN {for(dep=bpd;dep<=npd;dep+=pdi) { print "perl ../cmds/tel4.pl -O../greenFuncDir/"mdn" -M"mdn"/"dep, dist }}' | sh
echo -e "\033[35m Calculate the teleseismic green function \033[0m"

# --> change data and green b t1 t2
saclst gcarc f *.[rtz] | gawk '{if($2>=30&&$2<=90) print "r "$1; print "ch t1 20 t2 170 t3 20 t4 220"; print "wh";} END {print "quit";}' | sac
cd ../
cd greenFuncDir/$model_name/
for ((i=$bg_preliminary_depth;i<=$nd_preliminary_depth;i+=$prel_dep_interval));
do
	cd ${model_name}_$i;
	saclst gcarc f *.grn.* | gawk '{if($2>=30&&$2<=90) print "r "$1; print "ch b 0 t1 20 t2 20"; print "wh";} END {print "quit";}' | sac
	cd ..
done
cd ../../
echo -e "\033[35m Change data and green's b t1 t2 t3 t4 time \033[0m"
