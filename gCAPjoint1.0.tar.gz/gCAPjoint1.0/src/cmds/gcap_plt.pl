#########################################################
## * copyright: 2016-2020, Earth Science School of USTC
## * File name: cap_plt.pl
## * Description: Plot waveforms for gCAPjoint (Loc+Tel)
## *        Modified based on Lupei Zhu's origin script.
## * Producer: Zhe Jia
## * Date:05/04/2016
## * History:05/04/2016 v0.1
##           24/04/2019 v0.2 Qipeng Bai
##########################################################

sub plot {

	use Env qw(GCAPHOME);
	$conjugate="$GCAPHOME/bin/to_conjugate.awk";

	local($mdl, $t1, $t2, $am, $num_com, $sec_per_inch, $wt_tel_loc, $wt_P_SH, $wt_of_pnl, $dura, $f1_pnl, $f2_pnl, $f1_sw, $f2_sw) = @_;
	local($n_sta,$n_tel,$n_loc,$nn,$nn1,$nn2,$tt,$plt1,$plt2,$plt3,$plt4,$i,$nam,$com1,$com2,$j,$x,$y,@aa,$rslt,@name1,@name2,@aztk,@aztk_tel, $am1, $am2,@tel_rslt,@tel_rslt1,@tel_rslt2,@loc_rslt,@rslt_terms);
	local $keepBad = 0;
	@trace = ("1/255/255/255","3/0/0/0");       # plot data trace
	@name1 = ("Pnl(z)","Pnl(r)","Rayleigh(z)","Rayleigh(r)","Love(T)");
	@name2 = ("P","SH");
	$outps = "$mdl.ps";
  # if ($am>0.) {$am = "$am/1.1";} else {$am=-$am;}
	if ($am>0.) {$am = "$am";} else {$am=-$am;}
	open(FFF,"$mdl.out");
	@rslt = <FFF>;
	close(FFF);
	@meca = split('\s+',shift(@rslt));
	@variance = split('\s+',shift(@rslt));
	@tensor = split('\s+',$rslt[0]);
	@others = grep(/^#/,@rslt);
	@rslt=grep(!/^#/,@rslt);
	$i = 0; @aztk=();

	$rms_tel=0;
	$rms_loc=0;
	$rms_total=0;
	$rms_P=0;
	$rms_SH=0;

	$n_sta=0;
	$n_tel=0;
	$n_loc=0;
	$n_P=0;
	$n_SH=0;

	foreach (@rslt) {
        @rslt_terms = split;
        @stna_dist = split(/\//,$rslt_terms[1]);
        if($stna_dist[0]>=3000){
        $n_tel++;
		$tel_rslt[$n_tel-1] = $_;
		$n_sta++;
			for ($j=0;$j<=4;$j++){
				if ( $rslt_terms[$j*4+2]>0 ){ # teleseismic waveforms
					$rms_tel=$rms_tel+$rslt_terms[$j*4+2]*$rslt_terms[$j*4+3];
					if($j==0 ){  # first seg is P
						$n_P++;
						$rms_P=$rms_P+$rslt_terms[$j*4+2]*$rslt_terms[$j*4+3];
					}
					else{
						$n_SH++;
						$rms_SH=$rms_SH+$rslt_terms[$j*4+2]*$rslt_terms[$j*4+3];
					 }
				}
			}
        }
		elsif ($stna_dist[0]>0&&$stna_dist[0]<=3000){      # local waveforms
        $n_loc++;
		$n_sta++;
		$loc_rslt[$n_loc-1] = $rslt[$n_sta-1];
            for ($j=0;$j<=4;$j++){
				if ( $rslt_terms[$j*4+2]>0 ){
					$rms_loc=$rms_loc+$rslt_terms[$j*4+2]*$rslt_terms[$j*4+3];
                }
            }
        }
    }
 # print STDERR "tel_rslt=\n@tel_rslt\nloc_rslt=\n@loc_rslt\n";

	$nn1=$n_loc+1; # nn1: loc partion
	$n_temp=5;
	#$n_temp=int($n_sta/8)+2; # y range of loc and text information  5
	$n_title_loc=3;
	$n_title_tel=2;
#	$n_title_tel=int($n_temp/2); # y range of tel information 2

	if ($n_tel % 2 > 0 ) {$nn2=int($n_tel/2)+1} else {$nn2=int($n_tel/2)}; # nn2: tel partion
	($nn,$hight) = (int($nn2+$n_loc+$n_temp),25); # -J hight = 22cm 

  #  print STDERR "n_temp=$n_temp\nn_title_tel=$n_title_tel\nsec_per_inch=$sec_per_inch\nnn1=$nn1\nnn2=$nn2\n";

	$n_bar=$nn/5; # no use
	$sepa = 0.25*$sec_per_inch;
	($tt, $inc) = (2*$t1 + 3*$t2 + 4*$sepa, 1); # loc: 5 segments
	($tt, $inc) = ($t1 + $t2 + $sepa, 4) if $num_com == 2; # tel: 2 segments
	$width = 0.3*int(10*$tt/$sec_per_inch+0.5); # -J width = ? cm
	$width_P = 0.3*(10*$t1/$sec_per_inch);
	$width_SH = 0.3*(10*$t2/$sec_per_inch); 
	$width_sepa = 0.3*(10*$sepa/$sec_per_inch);
	@x0 = ($t1+$sepa, $t1+$sepa, $t2+$sepa, $t2+$sepa, $t2); # origin set of 5 segments
	@x1 = (0,$width_P+$width_sepa,2*$width_P+2*$width_sepa,2*$width_P+$width_SH+3*$width_sepa,2*$width_P+2*$width_SH+4*$width_sepa);

	$plt_begin = "| psxy -JX$width/$hight -R0/$tt/0/$nn -X4 -K -P > $outps";
	$plt1 = "| pssac2 -JX$width/$hight -R0/$tt/0/$nn -Ent-2 -M$am -K -O >> $outps";
	$plt1_tel_ori = "| pssac2 -JX$width/$hight -R0/$tt/0/$nn -Ent-2 -Xa -Ya -M$am -K -O >> $outps"; # absolute offset -Xa -Ya

	$plt_title = "| pstext -JX10/3 -R0/10/0/3 -Xa -Ya24 -O -K -N >> $outps"; # text in the title
	$plt2 = "| pstext -JX -R -Xa -Ya -O -K -N >> $outps"; # text in the title
	$plt3 = "| psmeca -JX3/3 -R-1/1/-1/1 -Sa15 -G100 -Xa-3 -Ya24 -T0 -O -K >> $outps"; # beachball by DC
	$plt3 = "| psmeca -JX3/3 -R-1/1/-1/1 -Sm24 -G100 -Xa-3 -Ya24 -T0 -O -K >> $outps" if $tensor[1] eq "MomentTensor"; # beachball by momenttensor
	$plt4 = "| psxy -JPa3 -R0/360/0/1 -Xa-3 -Ya24 -St0.25 -W0.5p/255/255/0 -G255/0/0 -O -K >> $outps"; # stations on the beachball of loc(triangle) 
	$plt4_tel = "| psxy -JPa3 -R0/360/0/1 -Xa-3 -Ya24 -Si0.2 -W0.5p/255/255/0 -G255/0/0 -O -K >> $outps"; # stations on the beachball of tel(triangle)
	$plt_end = "| psxy -JX -R -O >> $outps";

	foreach (@loc_rslt) {
		@aa = split;
		next if $aa[2] == 0;
		$x = `saclst az user1 f ${mdl}_$aa[0].0`;
		@aa = split(' ', $x);
		if ($aa[2]>90.) {$aa[1] += 180; $aa[2]=180-$aa[2];}
		$aztk[$i] = sprintf("%s %f\n",$aa[1],sqrt(2.)*sin($aa[2]*3.14159/360));
		$i++;
	} # check the azimuthal take-off
	
	unlink($outps) if -e $outps; # if there is outps, delete it
	open(PLT, $plt_begin);
	printf PLT;
	close(PLT);

################## title #################################
	open(PLT, $plt_title);
	$x=0;
	$y=2;
	my @meca_conjugate=`gawk -f $conjugate $meca[5] $meca[6] $meca[7]`;
	@meca_conj=split('\s+',@meca_conjugate[0]);
	@meca_depth=split('_',$meca[3]);
	@VR=split(' ',$variance[3]);
	printf PLT "$x $y 13 0 0 0 Depth: $meca_depth[1]km  @meca[8]: @meca[9] Duration: $dura VR: %s\045 \n",$VR[0]; $y-=0.5;
	printf PLT "$x $y 13 0 0 0 NP1: @meca[5]\260/@meca[6]\260/@meca[7]\260  NP2: @meca_conj[0]\260/@meca_conj[1]\260/@meca_conj[2]\260  @meca[17]: @meca[18]\261@meca[19] @meca[20]: @meca[21]\261@meca[22]  \n";$y-=0.5;
	printf PLT "$x $y 13 0 0 0 Moment Tensor(rtp): @tensor[9,4,7,6] %.3f %.3f\n",-$tensor[8],-$tensor[5];$y-=0.5;
    printf PLT "$x $y 13 0 0 0 Filter: P($f1_pnl-$f2_pnl Hz) SH($f1_sw-$f2_sw Hz) \n";$y-=0.5;
	close(PLT);  # plot the loc station —— distance and azmutal , CC and time_shift and meca  (pstext)

    open(PLT, $plt3);
    if ($tensor[1] eq "MomentTensor") {
		printf PLT "0 0 0 @tensor[9,4,7,6] %f %f 17\n",-$tensor[8],-$tensor[5];
    }
	else {
		print PLT "0 0 0 @meca[5,6,7] 1\n";
    }
    close(PLT); # plot the beach ball (psmeca)

    open(PLT, $plt4);
    foreach (@aztk) {
      print PLT;
    }
    close(PLT); # plot the stan on the beach ball (psxy)

####################### loc waveform part ###################
	while (@loc_rslt) {	

		open(PLT, $plt1);
		$i=0;
		@aaaa = splice(@loc_rslt,0,$nn1-1);
		foreach (@aaaa) {

			@aa = split;
			$nam = "${mdl}_$aa[0].";
			$x=0; # plot origin set is 0
			for($j=0;$j<5;$j+=$inc) {
				$com1=8-2*$j; $com2=$com1+1;
				if ($aa[4*$j+2]>0) {
                    
					if ($i==0 && j==0) {
						#printf PLTORI "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn-$i-$n_title_loc;
						printf PLT "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn-$i-$n_title_loc;
						printf PLT "%s %f %f 5/255/0/0\n",$nam.$com2,$x,$nn-$i-$n_title_loc;
					}
					else {
						printf PLT "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn-$i-$n_title_loc;
						printf PLT "%s %f %f 5/255/0/0\n",$nam.$com2,$x,$nn-$i-$n_title_loc;
					}
				}
				elsif ($keepBad) {
					if ($i==0&&$j==0) {
						#printf PLTORI "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn-$i-$n_title_loc;
						printf PLT "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn-$i-$n_title_loc;
						printf PLT "%s %f %f 3/200/200/200\n",$nam.$com2,$x,$nn-$i-$n_title_loc;
					}
					else {
						printf PLT "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn-$i-$n_title_loc;
						printf PLT "%s %f %f 3/200/200/200\n",$nam.$com2,$x,$nn-$i-$n_title_loc;
					}
				}
				$x = $x + $x0[$j];
			}
			$i++;
		}
#		close (PLTORI);  # plot the basemap (pssac2)
		close(PLT); # plot the loc seismogram (pssac2)
    
		open(PLT, $plt2);
		$y=$nn-$n_title_loc;
		foreach (@aaaa) {
			@aa = split;
			$x = 0;
			$x1 = `saclst az dist f ${mdl}_$aa[0].0`; # for az
			@aa1 = split(' ', $x1); # for az
			@bb1 = split(/\./, $aa[0]);
			printf PLT "%f %f 10 0 0 1 %s.%s\n",$x-0.8*$sec_per_inch,$y,$bb1[0],$bb1[1];
		    printf PLT "%f %f 8 0 0 1 %d\260 %.1fkm\n",$x-0.8*$sec_per_inch,$y-0.35,$aa1[1],$aa1[2]; # plot the distance and azimuth
			for($j=0;$j<5;$j+=$inc) {
				if ($aa[4*$j+2]>0 || $keepBad) {
					printf PLT "%f %f 8 0 0 1 $aa[4*$j+5]\n",$x,$y-0.3; # time_shift
					printf PLT "%f %f 8 0 0 1 $aa[4*$j+4]\045\n",$x,$y-0.6; # cc
				}
				$x = $x + $x0[$j]; # next wave segment （Pz、Pr）
			}
			$y--; # next line
		}

		$x = 0.2*$sec_per_inch;
	    for($j=0;$j<5;$j+=$inc) {
		printf PLT "%f %f 15 0 0 1 $name1[$j]\n",$x,$nn-1.3; # Pnl_z Pnl_r Rayleigh_z Rayleigh_r Love_t
		$x = $x+$x0[$j];
	    }
		close(PLT);
        
		$y_loc_tick=-2.2;
        `gmtset ANNOT_FONT_SIZE_PRIMARY = 8p`;
		`gmtset ANNOT_OFFSET_PRIMARY = 0.05c`;
		open(PLT, "| pssac2 -JX$width_P/$hight -R0/$t1/0/$nn -Ba50f25::N  -Ent-2 -M$am -Xa$x1[0] -Ya$y_loc_tick -K -O >> $outps");
		close(PLT);
		open(PLT, "| pssac2 -JX$width_P/$hight -R0/$t1/0/$nn -Ba50f25::N -Ent-2 -M$am -Xa$x1[1] -Ya$y_loc_tick -K -O >> $outps");
		close(PLT);			  
		open(PLT, "| pssac2 -JX$width_SH/$hight -R0/$t2/0/$nn -Ba50f25::N -Ent-2 -M$am -Xa$x1[2] -Ya$y_loc_tick -K -O >> $outps");
		close(PLT);			  
		open(PLT, "| pssac2 -JX$width_SH/$hight -R0/$t2/0/$nn -Ba50f25::N -Ent-2 -M$am -Xa$x1[3] -Ya$y_loc_tick -K -O >> $outps");
		close(PLT);			  
		open(PLT, "| pssac2 -JX$width_SH/$hight -R0/$t2/0/$nn -Ba50f25::N -Ent-2 -M$am -Xa$x1[4] -Ya$y_loc_tick -K -O >> $outps");
		close(PLT);	
		`gmtset ANNOT_OFFSET_PRIMARY = 0.2c`;
		`gmtset  ANNOT_FONT_SIZE_PRIMARY = 14p`;	  
	} 

############## Teleseismic waveform part 1 ########################
	($tt_tel, $inc) = ($t1 + $t2 + $sepa, 4) ;
	$width = 0.3*int(10*$tt/$sec_per_inch+0.5);
	$x0_tel = $t1+$sepa;

	$i=0; $j=0;
    foreach (@tel_rslt) {
		if ($i<$nn2){
	        $tel_rslt1[$i]=$_;
	        $i++;
	    }
	    else {
	        $tel_rslt2[$j]=$_;
	        $j++;
	    }
    } # separate the tel result in two part

	$i=0; $j=0; $y=$nn2; 
    while (@tel_rslt1) {
		open(PLT, $plt1);
#		open (PLTORI, $plt1_tel_ori);
		@aaaa = splice(@tel_rslt1,0,$nn2-1);
		foreach (@aaaa) {
			@aa = split;
			$nam = "${mdl}_$aa[0].";
			$x=0;
			for($j=0;$j<5;$j+=$inc) {
				$com1=8-2*$j; $com2=$com1+1;
				if ($aa[4*$j+2]>0) {

					if ($i==0&&$j==0) {
						#printf PLTORI "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 5/255/0/0\n",$nam.$com2,$x,$nn2-$i;
					}
					else {
						printf PLT "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 5/255/0/0\n",$nam.$com2,$x,$nn2-$i;
	                }
				}
				elsif ($keepBad) {
					if ($i==0&&$j==0) {
						#printf PLTORI "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 3/200/200/200\n",$nam.$com2,$x,$nn2-$i;
					}
					else {
						printf PLT "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 3/200/200/200\n",$nam.$com2,$x,$nn2-$i;
					}
				}
				$x = $x + $x0_tel;
			}
			$i++;
		}
#		close (PLTORI);
		close(PLT);

		open(PLT, $plt2);
		foreach (@aaaa) {
			@aa = split;
			$x = 0;
			$x1 = `saclst az dist knetwk kstnm f ${mdl}_$aa[0].0`; # for az
			@aa1 = split(' ', $x1); # for az
			@bb1 = split(/\./, $aa[0]);
			printf PLT "%f %f 10 0 0 1 %s.%s\n",$x-0.8*$sec_per_inch,$y,$bb1[0],$bb1[1]; # 
			printf PLT "%f %f 8 0 0 1 %d\260 %.1fkm\n",$x-0.8*$sec_per_inch,$y-0.35,$aa1[1],$aa1[2]; #
			for($j=0;$j<5;$j+=$inc) {
				if ($aa[4*$j+2]>0 || $keepBad) {
					printf PLT "%f %f 8 0 0 1 $aa[4*$j+5]\n",$x,$y-0.3; # tel: time_shift
					printf PLT "%f %f 8 0 0 1 $aa[4*$j+4]\045\n",$x,$y-0.6; # cc
				}
				$x = $x + $x0_tel;
			}
			$y = $y-1; 
		}
		$x = 0.2*$sec_per_inch;
		for($j=0;$j<2;$j+=1) {
			printf PLT "%f %f 15 0 0 1 $name2[$j]\n",$x,$nn2+0.8; # P_z, SH_t
			$x = $x+$x0[$j];
		}
		close(PLT);

        `gmtset ANNOT_FONT_SIZE_PRIMARY = 8p`;
		`gmtset ANNOT_OFFSET_PRIMARY = 0.05c`;
	    `gmtset LABEL_FONT_SIZE = 14p`;
		open(PLT, "| pssac2 -JX$width_P/$hight -R0/$t1/0/$nn -Ba50f25:\"Time(s)\":S -Ent-2 -M$am -Xa$x1[0] -Ya0 -K -O >> $outps");
		close(PLT);
		open(PLT, "| pssac2 -JX$width_SH/$hight -R0/$t2/0/$nn -Ba50f25:\"Time(s)\":S -Ent-2 -M$am -Xa$x1[1] -Ya0 -K -O >> $outps");
		close(PLT);
	    `gmtset LABEL_FONT_SIZE = 24p`;
		`gmtset ANNOT_OFFSET_PRIMARY = 0.2c`;
		`gmtset ANNOT_FONT_SIZE_PRIMARY = 14p`;
	}

######################## teleseismic waveforms part 2 #################################
	$i=0; $j=0; $y=$nn2;
	while (@tel_rslt2) {
		open(PLT, $plt1);
#        open (PLTORI, $plt1_tel_ori);
		@aaaa = splice(@tel_rslt2,0,$nn2-1);
		foreach (@aaaa) {
			@aa = split;
			$nam = "${mdl}_$aa[0].";
			$x=$t1+2*$t2+3*$sepa;

			@x2= ($width_P+2*$width_SH+3*$width_sepa,2*$width_P+2*$width_SH+4*$width_sepa);

			for($j=0;$j<5;$j+=$inc) {
			$com1=8-2*$j; $com2=$com1+1;
				if ($aa[4*$j+2]>0) {
					if ($i==0&&$j==0) {
						#printf PLTORI "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 5/255/0/0\n",$nam.$com2,$x,$nn2-$i;
					}
					else {
						printf PLT "%s %f %f 5/0/0/0\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 5/255/0/0\n",$nam.$com2,$x,$nn2-$i;
					}
				}
				elsif ($keepBad) {
					if ($i==0&&$j==0) {
						#printf PLTORI "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 3/200/200/200\n",$nam.$com2,$x,$nn2-$i;
					}
					else {
						printf PLT "%s %f %f 2/200/200/200\n",$nam.$com1,$x,$nn2-$i;
						printf PLT "%s %f %f 3/200/200/200\n",$nam.$com2,$x,$nn2-$i;
					}
				}
				$x = $x + $x0_tel;
			}
			$i++;
		}
#		close(PLTORI);
		close(PLT);

################################### plot the moment tensor beachball ###########################
		open(PLT, $plt2);
		foreach (@aaaa) {
			@aa = split;
			$x = $t1+2*$t2+3*$sepa;
			$x1 = `saclst az dist f ${mdl}_$aa[0].0`; # for az
			@aa1 = split(' ', $x1); # for az
			@bb1 = split(/\./, $aa[0]);
			printf PLT "%f %f 10 0 0 1 %s.%s\n",$x-0.8*$sec_per_inch,$y,$bb1[0],$bb1[1];
			printf PLT "%f %f 10 0 0 1 $aa[0]\n",$x-0.8*$sec_per_inch,$y;
			printf PLT "%f %f 8 0 0 1 %d\260 %.1fkm\n",$x-0.8*$sec_per_inch,$y-0.35,$aa1[1],$aa1[2];
			for($j=0;$j<5;$j+=$inc) {
				if ($aa[4*$j+2]>0 || $keepBad) {
					printf PLT "%f %f 8 0 0 1 $aa[4*$j+5]\n",$x,$y-0.3;
					printf PLT "%f %f 8 0 0 1 $aa[4*$j+4]\045\n",$x,$y-0.6;
				}
				$x = $x + $x0_tel;
			}
			$y = $y-1;
		}
		$x = 0.2*$sec_per_inch+$t1+2*$t2+3*$sepa;
		for($j=0;$j<2;$j+=1) {
			printf PLT "%f %f 15 0 0 1 $name2[$j]\n",$x,$nn2+0.8;
			$x = $x+$x0[$j];
		}
		close(PLT);
	}
    
	`gmtset ANNOT_FONT_SIZE_PRIMARY = 8p`;
	`gmtset ANNOT_OFFSET_PRIMARY = 0.05c`;
	`gmtset LABEL_FONT_SIZE = 14p`;
	open(PLT, "| pssac2 -JX$width_P/$hight -R0/$t1/0/$nn -Ba50f25:\"Time(s)\":S -Ent-2 -M$am -Xa$x2[0] -Ya0 -K -O >> $outps");
	close(PLT);
	open(PLT, "| pssac2 -JX$width_SH/$hight -R0/$t2/0/$nn -Ba50f25:\"Time(s)\":S -Ent-2 -M$am -Xa$x2[1] -Ya0 -K -O >> $outps");
	close(PLT);
	`gmtset LABEL_FONT_SIZE = 24p`;
	`gmtset ANNOT_OFFSET_PRIMARY = 0.2c`;
	`gmtset ANNOT_FONT_SIZE_PRIMARY = 14p`;

	$i=0;
	foreach (@tel_rslt) {
		@aa = split;
		next if $aa[2] == 0;
		$x = `saclst az user1 f ${mdl}_$aa[0].0`;
		@aa = split(' ', $x);
		if ($aa[2]>90.) {$aa[1] += 180; $aa[2]=180-$aa[2];}
		$aztk_tel[$i] = sprintf("%s %f\n",$aa[1],sqrt(2.)*sin($aa[2]*3.14159/360));
		$i++;
	}
    open(PLT, $plt4_tel);
    foreach (@aztk_tel) {
      print PLT;
    }
    close(PLT);
###############
    open(PLT, $plt_end);
    printf PLT;
    close(PLT);
}
1
