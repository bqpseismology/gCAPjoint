#!/usr/bin/perl 

@ARGV == 1 or die "Usage: perl $0 dirname \n";
$ENV{SAC_DISPLAY_COPYRIGHT}=0;
($dir) = @ARGV;

chdir $dir;
$snr="../cmds/snr/snr";
#$zr=$ARGV[0];
#$tr=$ARGV[1];
#$rr=$ARGV[2];
@HZ_data=<*.z>;
foreach $HZ (@HZ_data){
	($tmp,$time,$khole,$com)=split(/\./,$HZ);
	$HT="$tmp"."\."."$time"."\."."$khole"."\."."t";
	($junk,$zsnr)=split('=',`$snr $HZ t1 0 50`);
	($junk,$tsnr)=split('=',`$snr $HT t1 0 50`);

print "$HZ SNR=$zsnr $HT SNR=$tsnr \n";

open(SAC, "| sac") or die "Error in opening sac \n";
print SAC "r $HZ \n";
print SAC "ch user0 $zsnr\n";
print SAC "ch kuser0 SNR\n";
print SAC "wh \n";
print SAC "r $HT \n";
print SAC "ch user0 $tsnr\n";
print SAC "ch kuser0 SNR\n";
print SAC "wh \n";
print SAC "q\n";
close(SAC);
}

chdir "..";
