#!/bin/bash

# --> Set basic default factors
cd dataloc/
model_name="vmodel"
preliminary_depth=$(ls -1 *.z | gawk ' BEGIN{j=1;} {if(j<=1) print $1;j++;}' | gawk '{print "saclst evdp f "$1;}' | sh | gawk '{printf("%d",$2);}')


bg_preliminary_depth=$[$preliminary_depth-10]
if [ "$bg_preliminary_depth" -lt 1 ]
then
bg_preliminary_depth=1
fi
nd_preliminary_depth=$[$preliminary_depth+10]
prel_dep_interval=1

# --> Generate CRUST2 Velocity Model--loc
rm -rf $model_name
ls -1 *.z | gawk ' BEGIN{j=1;} {if(j<=1) print $1;j++;}' | gawk '{print "saclst evla evlo f "$1;}' | sh | gawk '{print $2,$3;}' > lalo.dat
cp -r ../cmds/crust2/ .
cp lalo.dat ./crust2/
cd ./crust2/
cat lalo.dat | gawk '{print $0;} END{print "*";}' | ./getCN2point 
cp outcr ../
cd ../
cat outcr | gawk 'NR>=6&&$1!=0{if($3!=0) {print $1,$3,$2,$4;} else {print $1,$3+0.01,$2,$4;}}' > model.tmp

if [ $preliminary_depth -le 70 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+1;}')
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_35 | head -1 | gawk '{print $4,$2,$1,$3;}' >> $model_name
fi

if [ $preliminary_depth -gt 70 ] && [ $preliminary_depth -le 300 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+3;}')
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_310 | head -3 | gawk '{print $4,$2,$1,$3;}' >> $model_name
fi

if [ $preliminary_depth -gt 300 ] && [ $preliminary_depth -le 400 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+3;}')
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_410 | head -3 | gawk '{print $4,$2,$1,$3;}' >> $model_name
fi

if [ $preliminary_depth -gt 400 ] ; then
num_layer=$(wc -l model.tmp | gawk '{print $1+4;}')
cat model.tmp | gawk '{print "echo "$0" >> '$model_name' ";}' | sh
cat ../cmds/prescribed_model_660 >>$model_name
cat ../cmds/prescribed_model_660 | head -4 | gawk '{print $4,$2,$1,$3;}' >> $model_name
fi
rm -rf ./crust2 lalo.dat model.tmp outcr
echo -e "\033[35m END Generate Crust2 velocity model \033[0m"

# --> getect greenFuncDir
if [ -d ../greenFuncDir ]; then
	echo "Found ../greenFuncDir/";
else
   	mkdir -p ../greenFuncDir/vmodel;
fi

# --> Calculate Green's Functions using fk
distlst=`saclst dist f *.z | sort -nk2 | gawk '{printf "%d ", $2} END {printf "\n"}'`
### DC ###
gawk -v mdn="$model_name" -v dist="$distlst" -v bpd="$bg_preliminary_depth" -v npd="$nd_preliminary_depth" -v pdi="$prel_dep_interval" 'BEGIN {for(dep=bpd;dep<=npd;dep+=pdi) {print "fk.pl -M"mdn"/"dep," -S2 -N1024/0.2", dist;}}' | sh 
### ISO ###
gawk -v mdn="$model_name" -v dist="$distlst" -v bpd="$bg_preliminary_depth" -v npd="$nd_preliminary_depth" -v pdi="$prel_dep_interval" 'BEGIN {for(dep=bpd;dep<=npd;dep+=pdi) {print "fk.pl -M"mdn"/"dep," -S0 -N1024/0.2 " dist; print "cp "mdn"_"dep"/* ../greenFuncDir/"mdn"/"mdn"_"dep"/"}}' | sh 
rm -rf vmodel_* junk.[ps]
cd ../
echo -e "\033[35m END Calculate fk \033[0m"
